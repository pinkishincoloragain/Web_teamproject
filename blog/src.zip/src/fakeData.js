export const fakeData = [
  {
    kind: "youtube#searchResult",
    etag: "VKFGGFS5sCQ0nXMVHLaXkDgSoyk",
    id: {
      kind: "youtube#video",
      videoId: "Mb-pqAnfaeI",
    },
    snippet: {
      publishedAt: "2020-02-29T03:53:07Z",
      channelId: "UCPiLe0hwTpPdvwKqQ0zgs0A",
      title: "[코드스테이츠] 배움의 기회를 미루지 마세요",
      description: "코드스테이츠 엔지니어 박준홍님의 불꽃연기를 감상하세요",
      thumbnails: {
        default: {
          url: "https://i.ytimg.com/vi/Mb-pqAnfaeI/default.jpg",
          width: 120,
          height: 90,
        },
      },
      channelTitle: "Code States",
      liveBroadcastContent: "none",
      publishTime: "2020-02-29T03:53:07Z",
    },
  },
];

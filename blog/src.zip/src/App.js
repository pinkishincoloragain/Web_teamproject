import React, { useState } from "react";
import Header from "./Header";
import Content from "./Content";
import Descript from "./Descript";
import Bar from "./SeperateBar";
import Map from "./Map";
import jQuery from "jquery";
import MapComponent from "./MapComponent";
import Video from "./Video";
import { searchYouTube } from "./searchYouTube";
import { fakeData } from "./fakeData";

const youTube = {
  query: "parkhyoshin",
  max: 1,
  key: "AIzaSyCZjpHedAQbWYnAqnwMTNQ24jeY8fweuZY",
};

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      videos: fakeData,
      current: fakeData[0],
    };
    this.handleSearch = this.handleSearch.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  // API를 요청하고 그에 따른 응답을 상태에 반영하는 함수
  goToSearch() {
    searchYouTube(youTube, (result) => {
      this.setState({ videos: [...result], current: result[0] });
    });
  }
  // 검색 버튼을 누르면 최종적으로 실행되는 함수
  // 새로운 검색어(newQuery)를 받아서 youTube 객체에 반영하고 goToSearch 메소드 실행
  handleSearch(newQuery) {
    newQuery = newQuery.split(".");
    alert("change: " + newQuery[0]);
    // alert("change");
    youTube.query = newQuery;
    this.goToSearch();
  }

  handleChange(videoKey) {
    for (let i = 0; i < this.state.videos.length; i++) {
      if (videoKey === this.state.videos[i].id.videoId) {
        this.setState({ current: this.state.videos[i] });
        break;
      }
    }
  }

  componentDidMount() {
    this.goToSearch();
  }

  render() {
    return (
      <div className="App">
        <div>
          <Header />
          <Bar />
        </div>
        <div>
          <Descript name="Let's get it started" color="#F7E600" />
          <div className="Contentdiv">
            <Content color="#F7E600" />
            <MapComponent search={this.handleSearch} />
          </div>
        </div>
        <div>
          <Descript name="Your Place" color="#543E47" />
          <div className="Contentdiv">
            <Content color="#543E47" />
          </div>
        </div>
        <div>
          <Descript name="Your News" color="#2DB400" />
          <div className="Contentdiv">
            <Content color="#2DB400" />
          </div>
        </div>
        <div>
          <Descript name="Your Youtube videos" color="#C4302B" />
          <div className="Contentdiv">
            {/* <Content color="#C4302B" /> */}
            <Video video={this.state.current} />
            <h1></h1>
          </div>
        </div>
        <div>
          <Descript name="Make comment on this place!" color="#E2DFD8" />
          <div className="Contentdiv">
            <Content color="#E2DFD8" />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
